<?php
/**
 * @package   T3 Blank
 * @copyright Copyright (C) 2005 - 2012 Open Source Matters, Inc. All rights reserved.
 * @license   GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;
?>

<section id="featuresSection" style="font-size: 0">
    <div class="auto">
        <ul>
            <?php $this->spotlight('spotlight-tiles', 'api-home-tiles-1, api-home-tiles-2, api-home-tiles-3, api-home-tiles-4, api-home-tiles-5, api-home-tiles-6') ?>
        </ul>
    </div>
</section>