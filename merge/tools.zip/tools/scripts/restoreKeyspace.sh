#!/bin/bash

function findScriptPath() {
    SOURCE="${BASH_SOURCE[0]}"
    while [ -h "$SOURCE" ]; do # resolve $SOURCE until the file is no longer a symlink
        DIR="$(cd -P "$(dirname "$SOURCE")" >/dev/null 2>&1 && pwd)"
        SOURCE="$(readlink "$SOURCE")"
        [[ $SOURCE != /* ]] && SOURCE="$DIR/$SOURCE" # if $SOURCE was a relative symlink, we need to resolve it relative to the path where the symlink file was located
    done
    DIR="$(cd -P "$(dirname "$SOURCE")" >/dev/null 2>&1 && pwd)"

    echo "$DIR"
}

function usage() {
    echo "===================================="
    echo "Usage of restoreKeyspace.sh"
    echo "-k Name of the keyspace to restore"
    echo "-s Name of the snapshot"
    echo "-h Usage"
    echo "===================================="
}

function loadConf() {
    config.section.cassandra

    CQLSH_BIN=$cqlsh_bin

    DATA_DIR=$cassandra_data_dir
    COMMITLOG_DIR=$cassandra_commitlog_dir
    SAVED_CACHES_DIR=$cassandra_saved_caches_dir

    config.section.backup
    BACKUP_ROOT_DIR=$backup_root_dir

    if [ ! -d "$BACKUP_ROOT_DIR" ]; then
        printError "Backup directory does not exist, impossible to perform restore"
        exit 1
    fi

    BACKUP_DIR="$BACKUP_ROOT_DIR/backup_$SNAPSHOT_NAME"

    BACKUP_SCHEMA_NAME=$KEYSPACE_NAME"_schema_backup.cql"
}

# ==========
# Usage
# Source the schema of the backup keyspace in Cassandra
#
# 1 - Check if the keyspace already exists
# 2 - If exist, ask the user if they want a fresh keyspace
# 3 - If yes, remove the keyspace via cqlsh drop keyspace and source the backup
# 4 - Else, print warning on the potential failure is there is still data inside and continue
# ==========
function cmdSourceFile() {

    SOURCEFILE=false

    if cmdCheckIfKeyspaceExit; then # Keyspace does not exist
        printDebug "Keyspace does not exist, continue"
        SOURCEFILE=true
    else
        printWarning "Keyspace $KEYSPACE_NAME already exist"
        if promptyn "Do you want to remove the existing keyspace and create a fresh one ?"; then
            printInfo "Remove existing keyspace"
            cmdRemoveExistingKeyspace
            cmdNodetoolFlush
            printDebug "Check the hard drive files"
            if [ -d "$DATA_DIR/$KEYSPACE_NAME" ]; then # Keyspace exist
                printDebug "Directory $DATA_DIR/$KEYSPACE_NAME exist, deleting it's content"
                local RM_CMD="rm -rf $DATA_DIR/$KEYSPACE_NAME/*"
                printCmd "$RM_CMD"
                eval "$RM_CMD"
            fi

            SOURCEFILE=true
        else
            printWarning "You have decided to keep the existing keyspace"
            printWarning "If the existing keyspace contain data, the restoration can fail"
        fi
    fi

    if [ -d "$DATA_DIR/$KEYSPACE_NAME" ]; then # Keyspace data exist
        printWarning "The keyspace does not exist in Cassandra, but there are still files for this keyspace on the hard drive at $DATA_DIR/$KEYSPACE_NAME"
        if promptyn "Do you want to remove the remaining data ? (The process will stop if you answer no)"; then
            printInfo "Deleting $DATA_DIR/$KEYSPACE_NAME content"
            local RM_CMD="rm -rf $DATA_DIR/$KEYSPACE_NAME/*"
            printCmd "$RM_CMD"
            eval "$RM_CMD"
        else
            printInfo "The restore process has been stopped"
            exit 1
        fi
    fi

    if [ $SOURCEFILE = true ]; then
        printInfo "Importing the schema for keyspace $KEYSPACE_NAME"
        CMD="$CQLSH_BIN $(getCqlshConnectionArgs) --file $BACKUP_DIR/$BACKUP_SCHEMA_NAME"

        printCmd "$CMD"

        eval "$CMD" >"$TMP_PATH"/.restoreKeyspace_cql_result.log 2>&1

        # Check if cqlsh return an error (Example: missing keyspace, or cassandra not running)
        TEST=$(cat "$TMP_PATH"/.restoreKeyspace_cql_result.log)
        rm "$TMP_PATH"/.restoreKeyspace_cql_result.log

        if [ -n "$TEST" ]; then
            printWarning "$TEST"
            printWarning "Importing the schema for keyspace $KEYSPACE_NAME returned the above, please review"
            if promptyn "Do you want to continue ?"; then
                printInfo "Continuing..."
                printSuccess "Schema for keyspace $KEYSPACE_NAME imported"
            else
                exit 1
            fi
        else
            printSuccess "Schema for keyspace $KEYSPACE_NAME imported"
        fi
    fi

}

# =========
# Usage
# Return 0 if the keyspace does not exists
# Return 1 otherwise
# =========
function cmdCheckIfKeyspaceExit() {
    printDebug "Check if keyspace $KEYSPACE_NAME exist"
    CMD="echo \"DESCRIBE $KEYSPACE_NAME;exit;\" | $CQLSH_BIN $(getCqlshConnectionArgs)"

    printCmd "$CMD"
    eval "$CMD" >"$TMP_PATH"/.restoreCheckIfKeyspaceExit.log 2>&1

    TEST=$(cat "$TMP_PATH"/.restoreCheckIfKeyspaceExit.log)
    rm "$TMP_PATH"/.restoreCheckIfKeyspaceExit.log

    if [[ $TEST =~ "not found in keyspaces" ]]; then
        printDebug "Keyspace does not exist"
        return 0
    else
        printDebug "Keyspace exist"
        return 1
    fi
}

# =========
# Usage
# Need a running cassandra
# Perform a "DROP keyspace" command
# =========
function cmdRemoveExistingKeyspace() {
    printDebug "Drop keyspace '$KEYSPACE_NAME'"
    CMD="echo \"DROP keyspace $KEYSPACE_NAME;exit;\" | $CQLSH_BIN $(getCqlshConnectionArgs)"

    printCmd "$CMD"
    eval "$CMD" >"$TMP_PATH"/.restoreRemoveExistingKeyspace.log 2>&1

    TEST=$(cat "$TMP_PATH"/.restoreRemoveExistingKeyspace.log)
    rm "$TMP_PATH"/.restoreRemoveExistingKeyspace.log

    if [[ -z $TEST ]]; then
        printDebug "Keyspace deleted"
    else
        printDebug "Impossible to delete keyspace"
        printError "$TEST"
        printError "Impossible to drop the keyspace $KEYSPACE_NAME, see error above"
        exit 1
    fi
}

# =========
# Usage
# Use cassandra_stop from axway-cassandra-backup.ini file
# Check is Cassandra is done with "nodetool status", 3 retry with 5s delay
# =========
function cmdStopCassandra() {

    local STOP_CASSANDRA=$cassandra_stop
    local NB_RETRY_MAX=3
    local NB_RETRY=-1

    printCmd "$STOP_CASSANDRA"
    eval "$STOP_CASSANDRA" >/dev/null 2>&1

    local STATUS=1
    while [ "$NB_RETRY" -lt "$NB_RETRY_MAX" ]; do
        if [ "$NB_RETRY" -gt "-1" ]; then
            printInfo "[Retry $((NB_RETRY + 1))/$NB_RETRY_MAX]"
        fi
        sleep 3s
        cmdNodetoolStatus
        STATUS=$?
        if [ "$STATUS" -ne "0" ]; then
            break
        fi

        sleep 2s
        ((NB_RETRY++))
    done

    if [ "$STATUS" -ne "0" ]; then
        printInfo "Cassandra stopped"
    else
        printError "Impossible to stop Cassandra"
        exit 1
    fi
}

# =========
# Usage
# Use cassandra_stop from axway-cassandra-backup.ini file
# Check is Cassandra is done with "nodetool status", 3 retry with 5s delay
# =========
function cmdCheckCassandraIsRunning() {

    printInfo "Check if Cassandra is running"

    cpt="0"
    QUIT=1
    while [ "$QUIT" -ne "0" ] && [ $cpt -lt 4 ]; do # Allow 4 tries to prevent infinite loop
        local NB_RETRY_MAX=3
        local NB_RETRY=-1

        # printCmd "$cmdNodetoolStatus"
        # eval cmdNodetoolStatus >/dev/null 2>&1

        local STATUS=1
        while [ "$NB_RETRY" -lt "$NB_RETRY_MAX" ]; do
            if [ "$NB_RETRY" -gt "-1" ]; then
                printInfo "[Retry $((NB_RETRY + 1))/$NB_RETRY_MAX]"
            fi
            sleep 3s
            cmdNodetoolStatus
            STATUS=$?
            if [ "$STATUS" -eq "0" ]; then
                break
            fi

            sleep 2s
            ((NB_RETRY++))
        done

        if [ "$STATUS" -eq "0" ]; then
            printInfo "Cassandra running"
            QUIT=0
        else
            if promptyn "Unable to detect a running Cassandra instance. Please check, and hit \"y\", or \"n\" to abort the restore process"; then
                printWarning "Restore keyspace aborted"
                exit 1
            fi
        fi
        cpt=$((cpt + 1))
    done
}

# =========
# Usage
# Run "nodetool status", return the status of the request
# 0 - Request sucessfull
# 1 - Error (Ex: Cassandra not running)
# =========
function cmdNodetoolStatus() {
    config.section.cassandra
    local NODETOOL=$nodetool_bin

    CMD="$NODETOOL$(getNodeToolConnectionArgs) status"

    printCmd "$CMD"
    eval "$CMD" >/dev/null 2>&1
    return $?
}

function cmdNodetoolFlush() {
    config.section.cassandra
    local NODETOOL=$nodetool_bin

    CMD="$NODETOOL$(getNodeToolConnectionArgs) flush"

    printCmd "$CMD"
    eval "$CMD" >/dev/null 2>&1
    return $?
}

SCRIPT_PATH=$(findScriptPath)
BASE_PATH="$SCRIPT_PATH/../"
TMP_PATH=$BASE_PATH/tmp
KEYSPACE_NAME=""
SNAPSHOT_NAME=""

mkdir -p $TMP_PATH

#Important to load the read-config first, other scripts needs it
source "$SCRIPT_PATH/utils/read-config.sh"
source "$SCRIPT_PATH/utils/parse-yaml.sh"
source "$SCRIPT_PATH/utils/logger.sh"
source "$SCRIPT_PATH/utils/cmd.sh"
source "$SCRIPT_PATH/utils/restoreKeyspaceData.sh"
source "$SCRIPT_PATH/utils/reloadIndexes.sh"

initLogger

if [ $# -eq 0 ]; then
    printError "No argument provided, see usage with -h"
    exit 1
fi

while getopts k:s:h flag; do
    case "${flag}" in
    k) KEYSPACE_NAME=${OPTARG} ;;
    s) SNAPSHOT_NAME=${OPTARG} ;;
    h | *)
        usage
        exit
        ;;
    esac
done

if [ -z "$KEYSPACE_NAME" ]; then
    printError "Keyspace name is empty"
    usage
    exit 1
fi

if [ -z "$SNAPSHOT_NAME" ]; then
    printError "Snapshot name is empty"
    usage
    exit 1
fi

printTitle "Restore keyspace $KEYSPACE_NAME"
printDebug "Keyspace name $KEYSPACE_NAME"
printDebug "Snapshot name $SNAPSHOT_NAME"

printInfo "Load configuration"
loadConf

printInfo "Check Cassandra"
checkCassandraRunning

printInfo "Check backup health"
checkIfBackupIsPresent "$BACKUP_DIR" "$SNAPSHOT_NAME" "$BACKUP_SCHEMA_NAME"

ACTION1="Make sure you have shut down all API Gateway instances and any other clients in the Cassandra cluster."
askUserForManualAction "$ACTION1"

printInfo "Create keyspace $BACKUP_SCHEMA_NAME in Cassandra"

cmdSourceFile

ACTION2="1- Drain and shut down each Cassandra node in the cluster, one node at a time."
ACTION3="Cmd to run: nodetool $(getNodeToolConnectionArgs) drain"
ACTION30="Cmd to run: stop-server (or your command to stop the Cassandra node)"
askUserForManualAction "$ACTION2" "$ACTION3" "$ACTION30"

printInfo "Delete commitlog directory content"
deleteFilesInDirectory "$COMMITLOG_DIR"

printInfo "Delete saved_caches directory content"
deleteFilesInDirectory "$SAVED_CACHES_DIR"

ACTION4="On the OTHER nodes in the cluster ONLY (do not do those actions on the node configured for this tool), perform the following:"
ACTION5="1- Delete all files in the commitlog and saved_caches directory."
ACTION6="2- Delete all files in the KEYSPACE being restored under the CASSANDRA_DATA_DIRECTORY."
ACTION7="Example cmd to run: rm -rf /opt/cassandra/data/data/$KEYSPACE_NAME/*"
askUserForManualAction "$ACTION4" "$ACTION5" "$ACTION6" "$ACTION7"

printInfo "Restore keyspace data"

if restoreKeyspaceData "$DATA_DIR" "$KEYSPACE_NAME" "$SNAPSHOT_NAME" "$BACKUP_DIR"; then
    printSuccess "Keyspace data restored successfully"
else
    printError "Impossible to restore data for the keyspace $KEYSPACE_NAME"
fi

ACTION8="One at a time, start the Cassandra seed node, and then the other nodes, and wait for each to be in Up/Normal (UN) state in nodetool status before you proceed to the next node."
askUserForManualAction "$ACTION8"

cmdCheckCassandraIsRunning

printInfo "Perform Nodetool flush"

if ! cmdNodetoolFlush; then
    printError "Impossible to do Nodetool flush"
    exit 1
fi

ACTION9="Perform a full repair of the cluster as follows on each node one at a time"
ACTION10="Cmd to run: nodetool $(getNodeToolConnectionArgs) repair -pr --full"
askUserForManualAction "$ACTION9" "$ACTION10"

printInfo "Perform Nodetool flush"

if ! cmdNodetoolFlush; then
    printError "Impossible to do Nodetool flush"
    exit 1
fi

printInfo "Reload indexes"
reloadIndexes "$CQLSH_BIN" "$(getCqlshConnectionArgs)" "$KEYSPACE_NAME" "$(getCassandraVersion)"

CMD="echo \"desc tables;exit;\" | $CQLSH_BIN $(getCqlshConnectionArgs)"
printCmd "${CMD}"

eval keyspace_tables=\$\($CMD\)
user_table="api_portal_portaluserstore"

if [ $(echo $keyspace_tables | grep -wc $user_table) -ne 0 ]; then
    CMD="echo \"select COUNT(*) from $KEYSPACE_NAME.$user_table;exit;\" | $CQLSH_BIN $(getCqlshConnectionArgs)"
    printCmd "${CMD}"
    eval count=\$\($CMD\)

    if [ $(echo $count | cut -d ' ' -f3) -eq 0  ]; then
        printError "No data returned when querying the users table '$user_table'. Please ensure to follow all manual action steps against Cassandra nodes and API Gateway instances during the restoration process." 
    else
        printSuccess "Restore successful"
    fi
else
    printSuccess "Restore successful"
fi
