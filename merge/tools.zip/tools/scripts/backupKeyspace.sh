#!/bin/bash

function findScriptPath() {
    SOURCE="${BASH_SOURCE[0]}"
    while [ -h "$SOURCE" ]; do # resolve $SOURCE until the file is no longer a symlink
        DIR="$(cd -P "$(dirname "$SOURCE")" >/dev/null 2>&1 && pwd)"
        SOURCE="$(readlink "$SOURCE")"
        [[ $SOURCE != /* ]] && SOURCE="$DIR/$SOURCE" # if $SOURCE was a relative symlink, we need to resolve it relative to the path where the symlink file was located
    done
    DIR="$(cd -P "$(dirname "$SOURCE")" >/dev/null 2>&1 && pwd)"

    echo "$DIR"
}

function usage() {
    echo "===================================="
    echo "Usage of backupKeyspace.sh"
    echo "-k Name of the keyspace to backup"
    echo "-s Name of the snapshot"
    echo "-f to force the backup (will overwrite the backup with the same name if it already exist)"
    echo "-h Usage"
    echo "===================================="
}

function loadConf() {
    config.section.cassandra

    CQLSH_BIN=$cqlsh_bin

    DATA_DIR=$cassandra_data_dir

    NODETOOL_BIN=$nodetool_bin

    config.section.backup
    BACKUP_ROOT_DIR=$backup_root_dir

    if [ ! -d "$BACKUP_ROOT_DIR" ]; then
        printWarning "Backup directory does not exist, creating it"
        mkdir -p "$BACKUP_ROOT_DIR"
    fi

    BACKUP_DIR="$BACKUP_ROOT_DIR/backup_$SNAPSHOT_NAME"

    BACKUP_NAME=$KEYSPACE_NAME"_schema_backup.cql"
}

function createBackupDir() {
    if [ "$FORCE_UPDATE" = true ]; then
        printWarning "Remove old backup"
        rm -rf "$BACKUP_DIR"
    fi

    if [ -d "${BACKUP_DIR}" ]; then
        printError "Backup '${BACKUP_DIR}' already exists in $BACKUP_ROOT_DIR"
        exit 1
    fi

    mkdir -p "$BACKUP_DIR"
}

function cmdCqlshExportSchema() {
    CMD="echo \"DESC keyspace $KEYSPACE_NAME; exit;\" | $CQLSH_BIN $(getCqlshConnectionArgs) > $BACKUP_DIR/$BACKUP_NAME"

    printCmd "$CMD"
    eval "$CMD" >"$TMP_PATH"/.backupKeyspace_cql_result.log 2>&1

    # Check if cqlsh return an error (Example: missing keyspace, or cassandra not running)
    TEST=$(cat "$TMP_PATH"/.backupKeyspace_cql_result.log)
    rm "$TMP_PATH"/.backupKeyspace_cql_result.log

    if [ -n "$TEST" ]; then
        printError "$TEST"
        printError "Impossible to export the schema for keyspace $KEYSPACE_NAME, see error above"
        exit 1
    else
        printSuccess "Schema export for keyspace $KEYSPACE_NAME"
    fi
}

function cmdClearSnapshot() {
    CLEARSNAPSHOT_CMD="$NODETOOL_BIN $(getNodeToolConnectionArgs) clearsnapshot -t $SNAPSHOT_NAME"

    printCmd "$CLEARSNAPSHOT_CMD"
    eval "$CLEARSNAPSHOT_CMD"
}

function cmdPerformSnapshot() {
    SNAPSHOT_CMD="$NODETOOL_BIN $(getNodeToolConnectionArgs) snapshot -t $SNAPSHOT_NAME $KEYSPACE_NAME"

    printCmd "$SNAPSHOT_CMD"
    eval "$SNAPSHOT_CMD"
}

SCRIPT_PATH=$(findScriptPath)
BASE_PATH="$SCRIPT_PATH/../"
TMP_PATH=$BASE_PATH/tmp
KEYSPACE_NAME=""
SNAPSHOT_NAME=""
FORCE_UPDATE=false

mkdir -p $TMP_PATH

#Important to load the read-config first, the logger needs it
source "$SCRIPT_PATH/utils/read-config.sh"
source "$SCRIPT_PATH/utils/parse-yaml.sh"
source "$SCRIPT_PATH/utils/logger.sh"
source "$SCRIPT_PATH/utils/cmd.sh"
source "$SCRIPT_PATH/utils/backupKeyspaceData.sh"

initLogger

if [ $# -eq 0 ]; then
    printError "No argument provided, see usage with -h"
    exit 1
fi

while getopts k:s:hf flag; do
    case "${flag}" in
    k) KEYSPACE_NAME=${OPTARG} ;;
    s) SNAPSHOT_NAME=${OPTARG} ;;
    f) FORCE_UPDATE=true ;;
    h | *)
        usage
        exit
        ;;
    esac
done

if [ -z "$KEYSPACE_NAME" ]; then
    printError "Keyspace name is empty"
    usage
    exit 1
fi

if [ -z "$SNAPSHOT_NAME" ]; then
    printError "Snapshot name is empty"
    usage
    exit 1
fi

printTitle "Backup keyspace $KEYSPACE_NAME"

printInfo "Loading configuration for keyspace backup"
loadConf

printInfo "Create backup directory"
createBackupDir

printInfo "Export keyspace schema into $BACKUP_NAME/$BACKUP_NAME"
cmdCqlshExportSchema

printInfo "Remove Snapshot $SNAPSHOT_NAME if exist"
cmdClearSnapshot

printInfo "Create snapshot with name $SNAPSHOT_NAME"
cmdPerformSnapshot

# 3 - Export keyspaces data
printInfo "Export keyspace data"

if backupKeyspaceData "$DATA_DIR" "$KEYSPACE_NAME" "$SNAPSHOT_NAME" "$BACKUP_DIR"; then
    printSuccess "Keyspace data exported to $BACKUP_DIR"
else
    printError "Impossible to create a snapshot for the keyspace $KEYSPACE_NAME"
fi
