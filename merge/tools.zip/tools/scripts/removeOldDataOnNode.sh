#!/bin/bash

# ==================================================================================================== #
# Script unsused for now, will be used in the v2 when the tool will be able to contact the others node #
# ==================================================================================================== #

function findScriptPath() {
    SOURCE="${BASH_SOURCE[0]}"
    while [ -h "$SOURCE" ]; do # resolve $SOURCE until the file is no longer a symlink
        DIR="$(cd -P "$(dirname "$SOURCE")" >/dev/null 2>&1 && pwd)"
        SOURCE="$(readlink "$SOURCE")"
        [[ $SOURCE != /* ]] && SOURCE="$DIR/$SOURCE" # if $SOURCE was a relative symlink, we need to resolve it relative to the path where the symlink file was located
    done
    DIR="$(cd -P "$(dirname "$SOURCE")" >/dev/null 2>&1 && pwd)"

    echo "$DIR"
}

function usage() {
    echo "===================================="
    echo "Usage of removeOldDataOnNode.sh"
    echo "-k Name of the keyspace to restore"
    echo "-h Usage"
    echo "===================================="
}

SCRIPT_PATH=$(findScriptPath)
KEYSPACE_NAME=""

#Important to load the read-config first, the logger needs it
source "$SCRIPT_PATH/utils/read-config.sh"
source "$SCRIPT_PATH/utils/parse-yaml.sh"
source "$SCRIPT_PATH/utils/cmd.sh"
source "$SCRIPT_PATH/utils/logger.sh"

initLogger

if [ $# -eq 0 ]; then
    printError "No argument provided, see usage with -h"
    exit 1
fi

while getopts k:h flag; do
    case "${flag}" in
    k) KEYSPACE_NAME=${OPTARG} ;;
    h | *)
        usage
        exit
        ;;
    esac
done

if [ -z "$KEYSPACE_NAME" ]; then
    printError "Keyspace name is empty"
    usage
    exit 1
fi

printTitle "Delete commitlog / saved_caches and keyspace content for keyspace $KEYSPACE_NAME"

printInfo "Delete commitlog directory content"
deleteFilesInDirectory "$cassConf_commitlog_directory"

printInfo "Delete saved_caches directory content"
deleteFilesInDirectory "$cassConf_saved_caches_directory"

printInfo "Delete keyspace data directory content"
deleteFilesInDirectory "$cassConf_data_file_directories__1"

printSuccess "Content deleted successfully"
