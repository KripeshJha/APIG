#!/bin/bash

# ==================================
# ini file parser
# Usage
# $1 - The ini file to parse
#
# Example: config_parser path/to/ini/file
# 1 - Load the section of the ini file you want
# config.section.sectionA
#
# 2 - Print the variable directly by it's name
# echo "$myConfigVar"
#
# ==================================
config_parser() {
    iniFile="$1"
    tmpFile=$(mktemp "/tmp/$(basename "$iniFile").XXXXXX")
    binSED=$(which sed)

    # copy the ini file to the temporary location
    cp "$iniFile" "$tmpFile"

    # remove tabs or spaces around the =
    $binSED -i -e 's/[ \t]*=[ \t]*/=/g' "$tmpFile"

    # transform section labels into function declaration
    $binSED -i -e 's/\[\([A-Za-z0-9_]*\)\]/config.section.\1() \{/g' "$tmpFile"
    $binSED -i -e 's/config\.section\./\}\'$'\nconfig\.section\./g' "$tmpFile"

    # remove first line
    $binSED -i -e '1d' "$tmpFile"

    # add the last brace
    echo -e "\n}" >>"$tmpFile"

    # now load the file
    source "$tmpFile"

    # clean up
    rm -f "$tmpFile"
}
