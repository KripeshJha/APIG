#!/bin/bash

PRINTCMD=false
DEBUG=false

function initLogger() {
    config.section.logger
    PRINTCMD=$printcmd
    DEBUG=$debug
}

function printTitle() {
    echo ""
    echo "========================================================================================"
    echo "$1"
    echo "========================================================================================"
}

function printError() {
    printMessage "[ERROR] $1"
}

function printWarning() {
    printMessage "[WARNING] $1"
}

function printInfo() {
    printMessage "[INFO] $1"
}

function printSuccess() {
    printMessage "[SUCCESS] $1"
}

function printManualAction() {
    printMessage "[MANUAL ACTION] $1"
}

function printDebug() {
    if [ "$DEBUG" = true ]; then
        printMessage "[DEBUG] $1"
    fi
}

function printCmd() {
    if [ "$PRINTCMD" = true ]; then
        echo "====================="
        echo "Cmd ran : $1"
        echo "====================="
    fi
}

function printMessage() {
    echo "$1"
}
