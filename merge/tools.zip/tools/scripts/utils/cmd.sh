#!/bin/bash

# =================
# Usage
# $1 - The question to ask the user
#
# Example: promptyn "Are you ok ?"
# =================
function promptyn() {
    i="0"
    text="[INFO] $1 (y/n)"
    while [ $i -lt 4 ]; do
        read -rp "$text" yn
        case $yn in
        [Yy]*) return 0 ;;
        [Nn]*) return 1 ;;
        *) echo "[INFO] Please answer yes or no." ;;
        esac
        i=$((i + 1))
    done
    printError "You did not answered, exit"
    exit 1
}

# =================
# Usage
# Use this method to ask the user to perform manual action
#
# All parameters will be prompted as manual actions that should be done
# Gonna also ask the user if he performed the ations, if not, gonna ask him if he want to leave the process
#
# Example: askUserForManualAction "Do action 1" "Remove folder XXX"
# Will print on console :
# [INFO] The next action requires a manual action from your side, see below
# [MANUAL ACTION] 1- Shut down all API Gateway instances and any other clients in the Cassandra cluster.
# [MANUAL ACTION] 2- Drain and shut down each Cassandra node in the cluster, one node at a time.
# [MANUAL ACTION] Cmd to run: nodetool CONNECTION_PARMS drain
# [INFO] Did you do all actions listed above ? (y/n)
#
# =================
function askUserForManualAction() {

    cpt="0"
    QUIT=1
    while [ "$QUIT" -ne "0" ] && [ $cpt -lt 4 ]; do # Allow 4 tries to prevent infinite loop
        printInfo ""
        printInfo "The next action requires a manual action from your side, see below"
        for var in "$@"; do
            printManualAction "$var"
        done

        # Check if the user answer yes. If not, propose him to stop the script, else reprint the manual actions
        if promptyn "Did you do all actions listed above ?"; then
            QUIT=0
        else
            if promptyn "Do you want to abort the restore process ?"; then
                printWarning "Restore keyspace aborted"
                exit 1
            fi
        fi
        cpt=$((cpt + 1))
    done

}

# =================
# Usage
# $1 - The directory where to delete the content
#
# Example: deleteFilesInDirectory path/to/commitlog_dir
# =================
function deleteFilesInDirectory() {
    if [ -z "$1" ]; then
        printError "No directory provied, impossible to delete content"
        exit 1
    fi

    local DIRECTORY=$1

    LAST_CHAR="${DIRECTORY: -1}"
    if [ "$LAST_CHAR" = "/" ]; then
        DIRECTORY="$DIRECTORY*"
    else
        DIRECTORY="$DIRECTORY/*"
    fi

    CMD="rm -rf $DIRECTORY"
    printCmd "$CMD"
    eval "$CMD"
}

# =================
# Usage
# Check if Cassandra is running
# Exit if it is not
# =================
function checkCassandraRunning() {
    config.section.cassandra
    $nodetool_bin status >/dev/null 2>&1
    isCassandraRunning=$?

    if [ $isCassandraRunning != 0 ]; then
        printError "Cassandra is not running"
        exit 1
    fi
}

# =================
# Usage
# Check if Nodetool path provided in configuration works
# Exit if it is not
# =================
function checkNodeTool() {
    config.section.cassandra
    $nodetool_bin version >/dev/null 2>&1
    isNodeToolRunning=$?

    if [ $isNodeToolRunning != 0 ]; then
        printError "Wrong configuration for Nodetool, check axway-cassandra-backup.ini"
        exit 1
    fi
}

# =================
# Usage
# Return version of Cassandra, using nodetool
# =================
function getCassandraVersion() {
    config.section.cassandra
    echo $($nodetool_bin version | sed 's/[^0-9]*//g')
}

# =================
# Usage
# Check if Cqlsh path provided in configuration works
# Exit if it is not
# =================
function checkCqlsh() {
    config.section.cassandra
    $cqlsh_bin --version >/dev/null 2>&1
    isCqlshRunning=$?

    if [ $isCqlshRunning != 0 ]; then
        printError "Wrong configuration for Cqlsh, check axway-cassandra-backup.ini"
        exit 1
    fi
}

# =================
# Usage
# $1 - the backup directory
# $2 - the snapshot name
# $3 - The keyspace name
#
# Example: checkIfBackupIsPresent /path/to/my/backup mySnapshot
# Exit 1 if the backup if not present
# =================
function checkIfBackupIsPresent() {
    local BACKUP_DIR=$1
    local SNAPSHOT_NAME=$2
    local KEYSPACE_SCHEMA=$3
    printDebug "Check if backup dir exits ($BACKUP_DIR)"
    if [ ! -d "$BACKUP_DIR" ]; then
        printError "Backup directory $BACKUP_DIR does not exist"
        exit 1
    fi

    printDebug "Check if snapshot dir exits ($SNAPSHOT_NAME)"
    if [ ! -d "$BACKUP_DIR/$SNAPSHOT_NAME" ]; then
        printError "Backup directory does not contain snapshot folder ($SNAPSHOT_NAME)"
        exit 1
    fi

    printDebug "Check if keyspace schema exits ($KEYSPACE_SCHEMA)"
    if [ ! -f "$BACKUP_DIR/$KEYSPACE_SCHEMA" ]; then
        printError "Backup directory does not contain keyspace schema ($KEYSPACE_NAME)"
        exit 1
    fi
}

# =================
# Usage
# Will echo the connection arguments to Nodetool, based on the configuration file
# =================
function getNodeToolConnectionArgs() {
    config.section.cassandra
    local CMD=""
    if [ -n "$nodetool_username" ]; then
        CMD="$CMD -u $nodetool_username"
    fi

    if [ -n "$nodetool_password" ]; then
        CMD="$CMD -pw $nodetool_password"
    fi

    echo "$CMD"
}

# =================
# Usage
# Will echo the connection arguments to Cqlsh, based on the configuration file
# =================
function getCqlshConnectionArgs() {
    config.section.cassandra
    local CMD="$cqlsh_ip"
    if [ -n "$cql_username" ]; then
        CMD="$CMD -u $cql_username"
    fi

    if [ -n "$cql_password" ]; then
        CMD="$CMD -p $cql_password"
    fi

    echo "$CMD"
}
