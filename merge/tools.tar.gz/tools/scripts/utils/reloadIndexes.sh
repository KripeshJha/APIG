#!/bin/bash

function reloadIndexesHelp() {
    echo "===================================="
    echo "Usage of reloadIndexes.sh"
    echo "\$1 Cqlsh command"
    echo "\$2 Cqlsh connection args"
    echo "\$3 Name of the keyspace"
    echo "\$4 Cassandra version"
    echo "===================================="
}

function reloadIndexes() {
    if [ "$#" -ne 4 ]; then
        echo "Illegal number of parameters"
        reloadIndexesHelp
        exit 1
    fi

    local CQLSH_BIN=$1
    local CQLSH_ARGS=$2
    local KEYSPACE_NAME=$3
    local CASSANDRA_VERSION=$4

    printDebug "Run reloadIndexes with the following parameters"
    printDebug "Cqlsh bin : $CQLSH_BIN"
    printDebug "Cqlsh params : $CQLSH_ARGS"
    printDebug "Keyspace name : $KEYSPACE_NAME"
    printDebug "Cassandra version :  $CASSANDRA_VERSION"
    printDebug ""

    cqlsh="${CQLSH_BIN} ${CQLSH_ARGS}"
    printInfo "Rebuilding indexes - all indexes will be rebuilt using nodetool rebuild_index"
    printInfo "Rebuild indexes for keyspace ${KEYSPACE_NAME}"
    set -e
    trap '[ "$?" -eq 0 ] || echo \*\*\* FATAL ERROR \*\*\*' EXIT $?
    indexes=$(mktemp)
    index_check=$(mktemp)

    printInfo "Getting indexes"


    if [[ $CASSANDRA_VERSION = 311* ]]; then
        # Cassandra 3.11.x
        printCmd "${cqlsh} -e \"SELECT index_name FROM system_schema.indexes WHERE keyspace_name = '${KEYSPACE_NAME}'\" > ${indexes}"
        ${cqlsh} -e "SELECT index_name FROM system_schema.indexes WHERE keyspace_name = '${KEYSPACE_NAME}'" > "${indexes}"
    else
        # Cassandra 2.2.x
        printCmd "${cqlsh} -e \"SELECT index_name FROM system.schema_columns WHERE keyspace_name = '${KEYSPACE_NAME}'\" > ${indexes}"
        ${cqlsh} -e "SELECT index_name FROM system.schema_columns WHERE keyspace_name = '${KEYSPACE_NAME}'" > "${indexes}"
    fi
    sed -i -e '1,3d;/^$/d;/null/d;$d' "${indexes}"
    if [ "$(wc -l < "${indexes}")" -eq 0 ]; then
        printError "Error getting current indexes"
        exit 1
    fi
    while IFS= read -r line; do
        index="${line#"${line%%[![:space:]]*}"}"
        printInfo "Restoring index: '${index}'"
        create_index=$(${cqlsh} -e "DESCRIBE INDEX ${KEYSPACE_NAME}.\"${index}\";")
        if [ $(echo ${create_index} | wc -l) -ne 1 ]; then
            printError "Error getting create script for index: ${index}"
            exit 1
        fi
        printDebug "Dropping index"
        printCmd "${cqlsh} -e \"DROP INDEX ${KEYSPACE_NAME}.\"${index}\";\""
        ${cqlsh} -e "DROP INDEX ${KEYSPACE_NAME}.\"${index}\";"
        printDebug "Creating index again"
        ${cqlsh} -e "${create_index}"
        printDebug "Checking created index"
        if [[ $CASSANDRA_VERSION = 311* ]]; then
            # Cassandra 3.11.x
            # DESC INDEX doesn't work with indexes that contain upper case letters
            printCmd "${cqlsh} -e \"SELECT index_name FROM system_schema.indexes WHERE keyspace_name = '${KEYSPACE_NAME}' AND index_name = '${index}' ALLOW FILTERING;\""
            ${cqlsh} -e "SELECT index_name FROM system_schema.indexes WHERE keyspace_name = '${KEYSPACE_NAME}' AND index_name = '${index}' ALLOW FILTERING;" > "${index_check}"
            sed -i -e '1,3d;/^$/d;/null/d;$d' "${index_check}"
            if [ "$(wc -l < "${index_check}")" -eq 0 ]; then
                printError "Error retrieving index ${index}"
                exit 1
            fi
        else
            # Cassandra 2.2.x
            printCmd "${cqlsh} -e \"DESCRIBE INDEX ${KEYSPACE_NAME}.${index};\""
            ${cqlsh} -e "DESCRIBE INDEX ${KEYSPACE_NAME}.${index};" >/dev/null
        fi

        printDebug "Done"
    done <"$indexes"

}
