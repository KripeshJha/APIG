#!/bin/bash

# =============================================================
# YAML Parser
# Usage
# $1 - The yaml file to parse
# $2 - A prefix to add to all parsed keys (optionnal)
#
# Example: eval $(parse_yaml /path/to/cassandra/yaml cassConf_)
# read yaml file with :
# echo $cassConf_commitlog_directory
#
# To see all parsed key, run the command without eval :
# parse_yaml $CASSCONFYAML "cassConf_"
# =============================================================
parse_yaml() {
    prefix=$2
    s='[[:space:]]*'
    w='[a-zA-Z0-9_]*'
    fs=$(echo @ | tr @ '\034')
    sed -ne "s|,$s\]$s\$|]|" \
        -e ":1;s|^\($s\)\($w\)$s:$s\[$s\(.*\)$s,$s\(.*\)$s\]|\1\2: [\3]\n\1  - \4|;t1" \
        -e "s|^\($s\)\($w\)$s:$s\[$s\(.*\)$s\]|\1\2:\n\1  - \3|;p" "$1" |
        sed -ne "s|,$s}$s\$|}|" \
            -e ":1;s|^\($s\)-$s{$s\(.*\)$s,$s\($w\)$s:$s\(.*\)$s}|\1- {\2}\n\1  \3: \4|;t1" \
            -e "s|^\($s\)-$s{$s\(.*\)$s}|\1-\n\1  \2|;p" |
        sed -ne "s|^\($s\):|\1|" \
            -e "s|^\($s\)-$s[\"']\(.*\)[\"']$s\$|\1$fs$fs\2|p" \
            -e "s|^\($s\)-$s\(.*\)$s\$|\1$fs$fs\2|p" \
            -e "s|^\($s\)\($w\)$s:$s[\"']\(.*\)[\"']$s\$|\1$fs\2$fs\3|p" \
            -e "s|^\($s\)\($w\)$s:$s\(.*\)$s\$|\1$fs\2$fs\3|p" |
        awk -F"$fs" '{
     indent = length($1)/2;
     vname[indent] = $2;
     for (i in vname) {if (i > indent) {delete vname[i]; idx[i]=0}}
     if(length($2)== 0){  vname[indent]= ++idx[indent] };
     if (length($3) > 0) {
        vn=""; for (i=0; i<indent; i++) { vn=(vn)(vname[i])("_")}
        printf("%s%s%s=\"%s\"\n", "'"$prefix"'",vn, vname[indent], $3);
     }
  }'
}
