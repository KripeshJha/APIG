#!/bin/bash

function restoreKeyspaceDataHelp() {
    echo "===================================="
    echo "Usage of backupKeyspaceData.sh"
    echo "\$1 Cassandra data directory"
    echo "\$2 Name of the keyspace"
    echo "\$3 Name of the snapshot"
    echo "\$4 Backup root directory"
    echo "===================================="
}

function restoreKeyspaceData() {

    if [ "$#" -ne 4 ]; then
        echo "Illegal number of parameters"
        restoreKeyspaceDataHelp
        exit 1
    fi

    local CASSANDRA_DATA_DIR=$1
    local KEYSPACE_NAME=$2
    local SNAPSHOT_NAME=$3
    local BACKUP_ROOT_DIR=$4

    printDebug "Run restoreKeyspaceData with the following parameters"
    printDebug "Cassandra data directory : $CASSANDRA_DATA_DIR"
    printDebug "Keyspace name : $KEYSPACE_NAME"
    printDebug "Snapshot name : $SNAPSHOT_NAME"
    printDebug "Backup root directory : $BACKUP_ROOT_DIR"
    printDebug ""

    backupdir="${BACKUP_ROOT_DIR}/${SNAPSHOT_NAME}"
    keyspace_path="${CASSANDRA_DATA_DIR}/${KEYSPACE_NAME}"
    printInfo "Restoring tables from directory, '${backupdir}', to directory, '${keyspace_path}'"
    set -e
    trap '[ "$?" -eq 0 ] || echo \*\*\* FATAL ERROR \*\*\*' EXIT $?
    if ! [ -d "${backupdir}" ]; then
        printError "Backup not found at '${backupdir}'"
        exit 1
    fi
    if ! [ -d "${keyspace_path}" ]; then
        printError "Keyspace path '${keyspace_path}' is not valid"
        exit 1
    fi
    keyspace_tables=$(mktemp)
    find "${keyspace_path}/" -maxdepth 1 -mindepth 1 -type d -fprintf "${keyspace_tables}" "%f\n"
    sort -o "${keyspace_tables}" "${keyspace_tables}"
    backup_tablenames=$(mktemp)
    find "${backupdir}/" -maxdepth 1 -mindepth 1 -type d -fprintf "${backup_tablenames}" "%f\n"
    sort -o "${backup_tablenames}" "${backup_tablenames}"
    keyspace_tablenames=$(mktemp)
    table_names=()
    table_uuids=()
    while IFS= read -r table; do
        str=${table##*/}
        uuid=${str##*-}
        len=$((${#str} - ${#uuid} - 1))
        name=${str:0:${len}}
        echo "${name}" >>"${keyspace_tablenames}"
        table_names+=("${name}")
        table_uuids+=("${uuid}")
    done <"${keyspace_tables}"
    set +e
    sort -o "${keyspace_tablenames}" "${keyspace_tablenames}"
    printDebug "keyspace_tablenames $keyspace_tablenames"
    printDebug "backup_tablenames $backup_tablenames"

    if ! diff -a -q "${keyspace_tablenames}" "${backup_tablenames}"; then
        printError "The tables on the keyspace at, '${keyspace_path}', are not the same as the ones from the backup at, '${backupdir}'"
        exit 1
    fi
    for ((i = 0; i < ${#table_names[*]}; i++)); do
        printDebug "Restoring table, '${table_names[i]}'"
        table_dir="${keyspace_path}/${table_names[i]}-${table_uuids[i]}"
        rm -r "${table_dir}"
        mkdir "${table_dir}"
        src="${backupdir}/${table_names[i]}"
        if [ -d "${src}" ] && [ "$(ls -A "${src}")" ]; then
            cp -r -a "${src}"/* "${table_dir}/"
        fi
    done
}
