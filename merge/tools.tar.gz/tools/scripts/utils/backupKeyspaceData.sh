#!/bin/bash

function backupKeyspaceDataHelp() {
    echo "===================================="
    echo "Usage of backupKeyspaceData.sh"
    echo "\$1 Cassandra data directory"
    echo "\$2 Name of the keyspace"
    echo "\$3 Name of the snapshot"
    echo "\$4 Backup root directory"
    echo "===================================="
}

function backupKeyspaceData() {

    if [ "$#" -ne 4 ]; then
        echo "Illegal number of parameters"
        backupKeyspaceDataHelp
        exit 1
    fi

    local CASSANDRA_DATA_DIR=$1
    local KEYSPACE_NAME=$2
    local SNAPSHOT_NAME=$3
    local BACKUP_ROOT_DIR=$4

    printDebug "Run backupKeyspaceData with the following parameters"
    printDebug "Cassandra data directory : $CASSANDRA_DATA_DIR"
    printDebug "Keyspace name : $KEYSPACE_NAME"
    printDebug "Snapshot name : $SNAPSHOT_NAME"
    printDebug "Backup root directory : $BACKUP_ROOT_DIR"
    printDebug ""

    backupdir="${BACKUP_ROOT_DIR}/${SNAPSHOT_NAME}"
    if [ -d "${backupdir}" ]; then
        printError "Snapshot '${SNAPSHOT_NAME}' already exists in the backup dir"
        return 1
    fi
    mkdir -p "${backupdir}"
    keyspace_path="${CASSANDRA_DATA_DIR}/${KEYSPACE_NAME}"
    if ! [ -d "${keyspace_path}" ]; then
        printError "Keyspace path '${keyspace_path}' is not valid"
        return 1
    fi
    snapshot_dirs=()
    find "${keyspace_path}/" -maxdepth 1 -mindepth 1 -type d ! -name "$(printf "*\n*")" >backup.tmp
    while IFS= read -r table_dir; do
        str=${table_dir##*/}
        table_uuid=${str##*-}
        len=$((${#str} - ${#table_uuid} - 1))
        table_name=${str:0:${len}}
        printDebug "Copy table: $table_name"
        current_backup_dir="${backupdir}/${table_name}"
        mkdir -p "${current_backup_dir}"
        current_snapshot="${table_dir}/snapshots/${SNAPSHOT_NAME}"
        snapshot_dirs+=("${current_snapshot}")
        if [ -d "${current_snapshot}" ] && [ "$(ls -A "${current_snapshot}")" ]; then
            cp -r -a "${current_snapshot}"/* "${current_backup_dir}/"
        fi
    done <backup.tmp
    rm backup.tmp
    printInfo "Removing snapshot files from Cassandra data directory"
    for dir in "${snapshot_dirs[@]}"; do
        rm -rf "${dir}"
    done
}
